from django.apps import AppConfig


class QtableAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'qtable_app'
