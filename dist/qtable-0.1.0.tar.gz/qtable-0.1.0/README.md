# QTable
QTable - Quote of day with django